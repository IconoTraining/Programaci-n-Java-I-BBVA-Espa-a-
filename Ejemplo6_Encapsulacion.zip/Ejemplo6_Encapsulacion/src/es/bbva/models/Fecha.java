package es.bbva.models;

public class Fecha {
	
	public int dia;
	public int mes;
	public int anyo;
	
	public void mostrar() {
		System.out.println(dia + "/" + mes + "/" + anyo);
	}

}
