package es.bbva.main;

import es.bbva.models.Fecha;
import es.bbva.models.FechaEncapsulada;

public class AppMain {

	public static void main(String[] args) {
		
		Fecha fecha = new Fecha();
		fecha.dia = 7886565;
		fecha.mes = -4332;
		fecha.anyo = 4;
		
		fecha.mostrar();
		
		
		FechaEncapsulada fechaEncapsulada = new FechaEncapsulada();
		fechaEncapsulada.setDia(7886565);
		fechaEncapsulada.setMes(-4332);
		fechaEncapsulada.setAnyo(4);
		
		fechaEncapsulada.mostrar();

	}

}
