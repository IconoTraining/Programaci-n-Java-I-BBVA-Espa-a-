package es.bbva.models;

public class Circulo extends Figura {

	private int radio;

	public Circulo() {
		// TODO Auto-generated constructor stub
	}

	public Circulo(int coordenadaX, int coordenadaY, int radio) {
		super(coordenadaX, coordenadaY);
		this.radio = radio;
	}

	public int getRadio() {
		return radio;
	}

	public void setRadio(int radio) {
		this.radio = radio;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + radio;
		return result * super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Circulo other = (Circulo) obj;
		if (radio != other.radio)
			return false;
		return true && super.equals(obj);
	}

	@Override
	public String toString() {
		return super.toString() + "radio=" + radio + " ";
	}

}
