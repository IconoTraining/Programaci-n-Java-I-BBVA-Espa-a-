package es.bbva.models;

public class Rectangulo extends Figura {

	private int ancho;
	private int alto;

	public Rectangulo() {
	}

	public Rectangulo(int coordenadaX, int coordenadaY, int ancho, int alto) {
		super(coordenadaX, coordenadaY);
		this.ancho = ancho;
		this.alto = alto;
	}

	public int getAncho() {
		return ancho;
	}

	public void setAncho(int ancho) {
		this.ancho = ancho;
	}

	public int getAlto() {
		return alto;
	}

	public void setAlto(int alto) {
		this.alto = alto;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + alto;
		result = prime * result + ancho;
		return result * super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Rectangulo other = (Rectangulo) obj;
		if (alto != other.alto)
			return false;
		if (ancho != other.ancho)
			return false;
		return true && super.equals(obj);
	}

	@Override
	public String toString() {
		return super.toString() + "ancho=" + ancho + ", alto=" + alto + " ";
	}

}
