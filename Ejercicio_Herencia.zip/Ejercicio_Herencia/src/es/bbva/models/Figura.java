package es.bbva.models;

public class Figura {

	private int coordenadaX;
	private int coordenadaY;

	public Figura() {
		// TODO Auto-generated constructor stub
	}

	public Figura(int coordenadaX, int coordenadaY) {
		super();
		this.coordenadaX = coordenadaX;
		this.coordenadaY = coordenadaY;
	}

	public void posicion() {
		// [x,y]
		System.out.println("[" + coordenadaX + "," + coordenadaY + "]");
	}

	public int getCoordenadaX() {
		return coordenadaX;
	}

	public void setCoordenadaX(int coordenadaX) {
		this.coordenadaX = coordenadaX;
	}

	public int getCoordenadaY() {
		return coordenadaY;
	}

	public void setCoordenadaY(int coordenadaY) {
		this.coordenadaY = coordenadaY;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + coordenadaX;
		result = prime * result + coordenadaY;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Figura other = (Figura) obj;
		if (coordenadaX != other.coordenadaX)
			return false;
		if (coordenadaY != other.coordenadaY)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "coordenadaX=" + coordenadaX + ", coordenadaY=" + coordenadaY + " ";
	}

}
