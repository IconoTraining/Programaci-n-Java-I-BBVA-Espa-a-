package es.bbva.main;

import es.bbva.models.Circulo;
import es.bbva.models.Rectangulo;

public class AppMain {

	public static void main(String[] args) {
		
		// Crear circulos
		Circulo circulo = new Circulo(5, 9, 20);
		circulo.posicion();
		System.out.println(circulo);
		
		Circulo circulo2 = new Circulo(5, 9, 20);
		System.out.println("Son iguales? " + (circulo.equals(circulo2)));
		
		
		// Crear rectangulos
		Rectangulo rectangulo = new Rectangulo(3, 8, 40, 20);
		rectangulo.posicion();
		System.out.println(rectangulo);
		
		Rectangulo rectangulo2 = new Rectangulo(3, 8, 40, 20);
		System.out.println("Son iguales? " + (rectangulo.equals(rectangulo2)));

	}

}
