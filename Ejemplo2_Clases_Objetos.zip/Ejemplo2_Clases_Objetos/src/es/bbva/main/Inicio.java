package es.bbva.main;

import es.bbva.models.Cliente;
import es.bbva.models.Direccion;

public class Inicio {

	// main + ctrl + space
	public static void main(String[] args) {
		
		int numero = 3;
		String nombre = "Pepito";
		
		Cliente objCliente = new Cliente();
		
		// Dar valores al objeto (personalizar)
		objCliente.nombre = "Transportes Lopez, S.L.";
		objCliente.cifraVentas = 18000;
		objCliente.esVip = false;
		
		// Crear una direccion
		Direccion dir = new Direccion();
		dir.calle = "Gran Via";
		dir.numero = 45;
		dir.poblacion = "Madrid";
		
		// Asignamos la direccion al objeto cliente
		objCliente.direccion = dir;
		
		objCliente.mostrarInformacion();
		
		objCliente.cambiarVip(true);
		objCliente.mostrarInformacion();
		
		System.out.println("Cifra de ventas: " +  objCliente.getCifraVentas() );   
		
	}

}
