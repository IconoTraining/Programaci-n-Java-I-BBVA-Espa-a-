package es.bbva.models;

public class Cliente {
	
	// caracteristicas, atributos o propiedades definen al cliente
	// como diferencias un cliente de otro cliente
	// Variable:   acceso tipo identificador;
	public String nombre;
	public double cifraVentas;
	public boolean esVip;
	public Direccion direccion;
	
	// metodos, acciones, funciones
	// Metodo:  acceso tipo nombre(lista de argumentos){}
	// void -> cuando el metodo no retorna nada
	public void mostrarInformacion() {
		System.out.println("Nombre: " + nombre + " Cifra de ventas: " +
				cifraVentas + " Vip: " + esVip + " Direccion: " + direccion.mostrar());
	}
	
	// Si el metodo retorna algun dato debemos poner de que tipo será
	public double getCifraVentas() {
		return cifraVentas;
	}
	
	public void cambiarVip(boolean nuevo) {
		esVip = nuevo;
	}

}
