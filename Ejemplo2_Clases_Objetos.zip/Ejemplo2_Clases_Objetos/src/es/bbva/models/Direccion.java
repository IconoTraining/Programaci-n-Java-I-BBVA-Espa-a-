package es.bbva.models;

public class Direccion {
	
	public String calle;
	public int numero;
	public String poblacion;
	
	public String mostrar() {
		// Gran Via, 45 - Madrid
		return calle + ", " + numero + " - " + poblacion;
	}

}
