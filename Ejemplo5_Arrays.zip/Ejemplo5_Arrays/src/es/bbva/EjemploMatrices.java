package es.bbva;

import java.util.Arrays;

public class EjemploMatrices {

	public static void main(String[] args) {
		
		// Crear un array de 2 dimensiones
		int numeros[][] = new int[2][4];  // 2 filas x 4 columnas = 8 elementos
		
		// Asignar valores
		numeros[0][0] = 7;
		numeros[0][1] = 2;
		numeros[0][2] = 9;
		numeros[0][3] = 6;
		numeros[1][0] = 1;
		numeros[1][1] = 3;
		numeros[1][2] = 5;
		numeros[1][3] = 8;
		
		// Todo en uno
		int numeros2[][] = { {7,2,9,6},  {1,3,5,8} };
		
		// Matrices no rectangulares
		// No todas las filas tienen el mismo numero de columnas
		int otro[][] = new int[2][];   // 2 filas
		otro[0] = new int[3];
		otro[1] = new int[5];
		
		// Recorrer con for tradicional
		for(int fila = 0; fila < numeros.length; fila++) {
			for(int columna = 0; columna < numeros[fila].length; columna++) {
				System.out.print(numeros[fila][columna] + "\t");
			}
			System.out.println();
		}
		
		// Recorrer con for each
		for (int fila[] : numeros) {
			for (int dato : fila) {
				System.out.print(dato + "\t");
			}
			System.out.println();
		}
		
		// Mostrar el array en consola
		System.out.println(numeros);
		System.out.println(Arrays.toString(numeros));
		System.out.println(Arrays.deepToString(numeros));
	}

}
