package es.bbva;

import java.util.Arrays;

public class EjemploArrays {

	public static void main(String[] args) {
		// Declarar una variable de tipo array
		int numeros[];
		int[] numeros2;
		int [] numeros3;
		
		int a[], b;
		int [] c, d;

		// Crear el array
		numeros = new int[3];   // 3 elementos (propiedad length)
		
		// Asignar valores al array
		numeros[0] = 6;
		numeros[1] = 2;
		numeros[2] = 9;
		
		// Todo en uno
		int numeros4[] = {6,2,9};
		int numeros5[] = new int[]{6,2,9};
		
		// Recorrer el array con for tradicional
		for(int i=0; i<numeros.length; i++) {
			System.out.println(numeros[i]);
		}
		
		// Recorrer con for each
		for(int num : numeros) {
			System.out.println(num);
		}
		
		// Mostrar el array
		System.out.println(numeros);   // muestra el identificador del objeto
		System.out.println(Arrays.toString(numeros));
		
		// Copiar en otro array
		int nuevo[] = new int[5];
		System.arraycopy(numeros, 0, nuevo, 0, numeros.length);
		System.out.println(Arrays.toString(nuevo));
	}
}






