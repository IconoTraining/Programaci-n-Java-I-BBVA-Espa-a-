package es.bbva.models;

public enum Traccion {
	
	DELANTERA, TRASERA, CUATRO_POR_CUATRO;
	
}
