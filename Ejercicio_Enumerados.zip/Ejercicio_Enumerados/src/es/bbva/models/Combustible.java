package es.bbva.models;

public enum Combustible {
	
	GASOLINA('B'),
	DIESEL('C'),
	ELECTRICO('A');
	
	private char clase;
	
	private Combustible(char clase) {
		this.clase = clase;
	}
	
	public char getClase() {
		return clase;
	}

}
