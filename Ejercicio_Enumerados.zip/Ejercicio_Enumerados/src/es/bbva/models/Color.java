package es.bbva.models;

public enum Color {

	BLANCO, NEGRO, ROJO, AZUL;
	
}
