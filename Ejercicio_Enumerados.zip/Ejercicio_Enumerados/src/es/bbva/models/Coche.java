package es.bbva.models;

public class Coche {
	
	private final int ID;
	private String marca;
	private double precio;
	private Color color;
	private Combustible combustible;
	private Traccion traccion;
	
	private static int contador;
	
	public Coche() {
		ID = ++contador;
	}

	public Coche(String marca, double precio, Color color, Combustible combustible, Traccion traccion) {
		super();
		ID = ++contador;
		this.marca = marca;
		this.precio = precio;
		this.color = color;
		this.combustible = combustible;
		this.traccion = traccion;
	}

	public int getID() {
		return ID;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	public Combustible getCombustible() {
		return combustible;
	}

	public void setCombustible(Combustible combustible) {
		this.combustible = combustible;
	}

	public Traccion getTraccion() {
		return traccion;
	}

	public void setTraccion(Traccion traccion) {
		this.traccion = traccion;
	}

	@Override
	public String toString() {
		return "Coche [ID=" + ID + ", marca=" + marca + ", precio=" + precio + 
				", color=" + color + ", combustible=" + combustible +
				", traccion=" + traccion + "]";
	}

}
