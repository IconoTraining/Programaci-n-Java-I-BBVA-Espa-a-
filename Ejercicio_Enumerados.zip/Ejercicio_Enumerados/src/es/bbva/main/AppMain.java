package es.bbva.main;

import es.bbva.models.Coche;
import es.bbva.models.Combustible;
import es.bbva.models.Traccion;

public class AppMain {

	public static void main(String[] args) {
		
		Coche coche1 = new Coche("Audi", 43000, es.bbva.models.Color.AZUL, 
				Combustible.ELECTRICO, Traccion.DELANTERA);
		Coche coche2 = new Coche("Mercedes", 52500, es.bbva.models.Color.BLANCO, 
				Combustible.GASOLINA, Traccion.TRASERA);
		
		System.out.println(coche1);
		System.out.println(coche2);
		
		System.out.println("Clase energetica: " + coche1.getCombustible().getClase());
		System.out.println("Clase energetica: " + coche2.getCombustible().getClase());

	}

}
