package es.bbva.models;

public class Circulo extends Figura {

	private int radio;

	public Circulo() {
		// TODO Auto-generated constructor stub
	}

	public Circulo(int x, int y, int radio) {
		super(x, y);
		this.radio = radio;
	}

	public int getRadio() {
		return radio;
	}

	public void setRadio(int radio) {
		this.radio = radio;
	}

	@Override
	public String toString() {
		return "Circulo [radio=" + radio + ", toString()=" + super.toString() + "]";
	}

	@Override
	public double calcularArea() {
		return Math.PI * Math.pow(radio, 2);
	}
	
}
