package es.bbva.main;

import es.bbva.models.Circulo;
import es.bbva.models.Figura;
import es.bbva.models.Rectangulo;

public class AppMain {

	public static void main(String[] args) {
		
		// Una clase abstracta, es una clase incabada y no se puede instanciar
		// Si que se pueden utilizar como tipo
		Figura circulo = new Circulo(6, 3, 25);
		System.out.println("Area circulo: " + circulo.calcularArea());
		
		// Figura figura = new Figura();   error
		
		// Clase anonima
		Figura triangulo = new Figura() {
			
			@Override
			public double calcularArea() {
				int base = 50;
				int altura = 30;
				return base * altura / 2;
			}
		};
		
		System.out.println("Area del triangulo: " + triangulo.calcularArea());
		
		Figura rectangulo = new Rectangulo(7, 4, 20, 40);
		System.out.println("Area rectangulo: " + rectangulo.calcularArea());
		System.out.println(rectangulo);
	}

}
