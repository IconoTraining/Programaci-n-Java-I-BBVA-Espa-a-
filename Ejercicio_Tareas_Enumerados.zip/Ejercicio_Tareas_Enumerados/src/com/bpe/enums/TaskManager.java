package com.bpe.enums;

public class TaskManager {

	public Task create(String creator) {
		Task task = new Task();
		task.setState(TaskState.STARTED);
		task.setCreator(creator);
		return task;
	} 
	
	public void assign(Task task, String user) {
		if (task.getState() != TaskState.STARTED) {
			throw new RuntimeException("Task is not in STARTED state");
		}
		task.setState(TaskState.PENDING);
		task.setOwner(user);
	}
	
	public void perform(Task task) {
		if (task.getState() != TaskState.PENDING) {
			throw new RuntimeException("Task is not in PENDING state");
		}
		task.setState(TaskState.PERFORMED);
	}
	
	public void review(Task task, boolean accept) {
		if (task.getState() != TaskState.PERFORMED) {
			throw new RuntimeException("Task is not in PERFORMED state");
		}
		if (accept) {
			task.setState(TaskState.COMPLETED);
		} else {
			task.setState(TaskState.PENDING);
		}
	}
}
