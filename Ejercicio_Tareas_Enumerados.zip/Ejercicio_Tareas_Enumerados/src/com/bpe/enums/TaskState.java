package com.bpe.enums;

public enum TaskState {
	
	STARTED, PENDING, PERFORMED, COMPLETED;
}
