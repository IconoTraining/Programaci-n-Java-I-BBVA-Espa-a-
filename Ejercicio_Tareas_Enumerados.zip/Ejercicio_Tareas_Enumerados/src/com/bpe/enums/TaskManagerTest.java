package com.bpe.enums;

public class TaskManagerTest {

	public static void main(String[] args) {
		
		// Crear una instancia de TaskManager
		TaskManager taskManager = new TaskManager();
		
		// Crear una instancia de Task, utilizando TaskManager. 
		// Verificar que está STARTED.
		Task task = taskManager.create("Pepito");
		System.out.println(task.getState());
		
		// Asignarla (assign) a un usuario. Verificar que está PENDING.
		taskManager.assign(task, "Maria");
		System.out.println(task.getState());
	
		// Ejecutarla (perform). Verificar que está PERFORMED.
		taskManager.perform(task);
		System.out.println(task.getState());
		
		// Revisarla (review), no aceptando el resultado.
		// Verificar que vuelve a estar PENDING
		taskManager.review(task, false);
		System.out.println(task.getState());
		
		// Volver a ejecutarla (perform). Verificar que está PERFORMED.
		taskManager.perform(task);
		System.out.println(task.getState());
		
		// Volver a revisarla, aceptando esta vez el resultado.
		// Verificar que queda COMPLETED
		taskManager.review(task, true);
		System.out.println(task.getState());
		
	}

}
