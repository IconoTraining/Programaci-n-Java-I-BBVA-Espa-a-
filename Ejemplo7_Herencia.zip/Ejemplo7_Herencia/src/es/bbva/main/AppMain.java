package es.bbva.main;

import es.bbva.models.Jefe;
import es.bbva.models.Persona;

public class AppMain {

	public static void main(String[] args) {
		// ctrl + shift + o   -> importa las clases
		
		Jefe jefe = new Jefe();
		jefe.setNombre("Juan");
		jefe.setEdad(35);
		jefe.setSueldo(47000);
		jefe.setCoche("1234-LXT");
		jefe.setTelefono(616111111L);
		
		//System.out.println(jefe.toString());
		System.out.println(jefe);
		
		Persona persona = new Persona("Pepito", 28, 616222222L);
		System.out.println(persona);
		
		Jefe jefe2 = new Jefe("Maria", 42, 616333333L, 54000, "9876-MBD");		
		Jefe jefe3 = new Jefe("Maria", 42, 616333333L, 54000, "9876-MBD");
		
		System.out.println("Son iguales? " + (jefe2 == jefe3) );
		System.out.println("Son iguales? " + (jefe2.equals(jefe3)) );
	}

}
