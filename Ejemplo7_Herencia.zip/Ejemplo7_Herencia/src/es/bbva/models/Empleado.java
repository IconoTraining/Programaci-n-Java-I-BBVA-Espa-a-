package es.bbva.models;

public class Empleado extends Persona {

	private double sueldo;

	// Constructores
	public Empleado() {
		// Esta invocando al constructor por defecto de la superclase
		super();
	}

	public Empleado(String nombre, int edad, long telefono, double sueldo) {
		super(nombre, edad, telefono);
		this.sueldo = sueldo;
	}

	public double getSueldo() {
		return sueldo;
	}

	public void setSueldo(double sueldo) {
		this.sueldo = sueldo;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		long temp;
		temp = Double.doubleToLongBits(sueldo);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result * super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Empleado other = (Empleado) obj;
		if (Double.doubleToLongBits(sueldo) != Double.doubleToLongBits(other.sueldo))
			return false;
		return true && super.equals(obj);
	}

	@Override
	public String toString() {
		return super.toString() + "sueldo=" + sueldo + " ";
	}

}
