package es.bbva.models;

public class Jefe extends Empleado {

	// propiedades
	private String coche;

	// constructores
	// El compilador si NO hay ningun constructor en la clase, genera el constructor
	// por defecto
	public Jefe() {
		// TODO Auto-generated constructor stub
	}

	public Jefe(String nombre, int edad, long telefono, double sueldo, String coche) {
		super(nombre, edad, telefono, sueldo);
		this.coche = coche;
	}

	// metodos
	public String getCoche() {
		return coche;
	}

	public void setCoche(String coche) {
		this.coche = coche;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((coche == null) ? 0 : coche.hashCode());
		return result * super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Jefe other = (Jefe) obj;
		if (coche == null) {
			if (other.coche != null)
				return false;
		} else if (!coche.equals(other.coche))
			return false;
		return true && super.equals(obj);
	}

	@Override
	public String toString() {
		return super.toString() + "coche=" + coche + " ";
	}

}
