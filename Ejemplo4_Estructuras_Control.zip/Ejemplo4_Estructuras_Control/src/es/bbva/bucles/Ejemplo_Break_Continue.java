package es.bbva.bucles;

public class Ejemplo_Break_Continue {

	public static void main(String[] args) {
		
		// Mostrar los numeros primos hasta el 100
		bucle_numeros:
		for (int numero = 1; numero <= 100; numero++) {
			boolean esPrimo = true;
			System.out.println("Probando numero: " + numero + " -----------");
			
			for(int divisor = 2; divisor < numero; divisor++) {
				System.out.println("------ Probando divisor: " + divisor);
				if (numero % divisor == 0) {
					esPrimo = false;
					//break;    // finalizar el bucle
					continue bucle_numeros; 
				}
			}
			
			if (esPrimo) System.out.println(numero);
		}

	}

}
