package es.bbva.bucles;

import java.util.Scanner;

public class Ejercicio_Numero_Aleatorio {

	public static void main(String[] args) {
		
		// Se trata de adivinar un numero entre 1 y 10, dando pistas
		int aleatorio = (int)(Math.random() * 10 + 1);
		boolean acertado = false;
		Scanner sc = new Scanner(System.in);
		
		do {
			System.out.println("Introduce un numero: ");
			int numero = sc.nextInt();
			
			if (numero > aleatorio) {
				System.out.println("Te has pasado, prueba con un numero menor");
			} else if (numero < aleatorio) {
				System.out.println("Te has quedado corto, prueba con un numero mayor");
			} else {
				System.out.println("Acertaste");
				acertado = true;
			}
			
		} while(!acertado);
		
		sc.close();
	}

}
