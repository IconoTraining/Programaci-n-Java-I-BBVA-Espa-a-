package es.bbva.bucles;

public class Ejemplo_For {

	public static void main(String[] args) {
		
		// Mostrar numeros del 1 al 10
		for (int numero = 1; numero <= 10; numero++) {
			System.out.println(numero);
		}
		
		// Mostrar numeros del 10 al 1
		for(int numero=10; numero > 0; numero--) {
			System.out.println(numero);
		}
		
		// Mostrar numeros del 0 al 10 de 2 en 2
		// numero += 2  ->   numero = numero + 2
		// numero /= 2  ->   numero = numero / 2
		for (int numero = 0; numero <= 10; numero += 2) {
			System.out.println(numero);
		}

	}

}
