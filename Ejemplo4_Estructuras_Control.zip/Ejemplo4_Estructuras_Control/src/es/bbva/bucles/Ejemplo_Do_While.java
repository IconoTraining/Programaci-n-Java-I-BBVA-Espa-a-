package es.bbva.bucles;

import java.util.Scanner;

public class Ejemplo_Do_While {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		String pw = "";
		
		do {
			System.out.println("Introduce password: ");
			pw = sc.nextLine();
			
		} while (!pw.equals("curso"));
		
		System.out.println("PW correcto");
		sc.close();

	}

}
