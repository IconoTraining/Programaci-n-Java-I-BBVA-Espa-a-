package es.bbva.bucles;

import java.util.Scanner;

public class Ejemplo_While {

	public static void main(String[] args) {
		
		// Solicitar pw al usuario hasta que acierte que es 'curso'
		String pw = "";
		Scanner sc = new Scanner(System.in);
		
		while (! pw.equals("curso")) {
			System.out.println("Introduce password: ");
			pw = sc.nextLine();
		}
		
		System.out.println("PW correcto");
		sc.close();

	}

}
