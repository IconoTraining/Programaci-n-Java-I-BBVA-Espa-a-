package es.bbva.bucles;

public class Ejemplo_For_Each {

	public static void main(String[] args) {
		
		int numeros[] = {1,7,4,6,2,5};
		int suma = 0;
		for (int num : numeros) {
			suma += num;      // suma = suma + num
		}
		System.out.println("Suma: " + suma);
	}

}
