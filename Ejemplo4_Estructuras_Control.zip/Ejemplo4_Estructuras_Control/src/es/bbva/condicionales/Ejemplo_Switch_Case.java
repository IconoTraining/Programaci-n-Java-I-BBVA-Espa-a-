package es.bbva.condicionales;

import java.util.Scanner;

public class Ejemplo_Switch_Case {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Introduce dia de la semana: ");
		char dia = scanner.next().charAt(0);
		
		switch (dia) {
		case 'l':
		case 'L':
			System.out.println("Es lunes");
			break;

		case 'm':
		case 'M':
			System.out.println("Es martes");
			break;

		case 'x':
		case 'X':
			System.out.println("Es miercoles");
			break;

		case 'j':
		case 'J':
			System.out.println("Es jueves");
			break;

		case 'v':
		case 'V':
			System.out.println("Es viernes");
			break;

		case 's':
		case 'S':
			System.out.println("Es sabado");
			break;

		case 'd':
		case 'D':
			System.out.println("Es domingo");
			break;
	
		default:
			System.out.println("Dia desconocido");
		}

	}

}
