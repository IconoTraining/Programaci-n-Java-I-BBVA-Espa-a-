package es.bbva.main;

import es.bbva.models.Empleado;
import es.bbva.models.Jefe;
import es.bbva.models.Persona;

public class AppMain {

	public static void main(String[] args) {
		Persona persona = new Persona("Pedro", 38, 616111111L);
		Empleado empleado = new Empleado("Elena", 52, 616222222L, 49000);
		Jefe jefe = new Jefe("Luis", 44, 616333333L, 58000, "9876-MBZ");
		
		AppMain appMain = new AppMain();
		appMain.procesar(persona);
		appMain.procesar(empleado);
		appMain.procesar(jefe);
	}
	
	public void procesar(Persona persona) {
		System.out.println("Hola, soy " + persona.getNombre() + 
				" y tengo " + persona.getEdad() + " años");
		
		// Cambiar la visibilidad a Empleado
		if (persona instanceof Empleado) {
			Empleado emp = (Empleado) persona;
			System.out.println("Sueldo: " + emp.getSueldo());
		}
		
		// Cambiar la visibilidad a Jefe
		if (persona instanceof Jefe) {
			System.out.println("Coche: " + ( (Jefe)persona).getCoche()  );
		}
		
	}

}
