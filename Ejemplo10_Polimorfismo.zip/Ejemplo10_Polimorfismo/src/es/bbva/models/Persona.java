package es.bbva.models;

// En Java todas las clases directa o indirectamente heredan de la clase Object
// En el momento de la compilacion, si la clase no hereda de otra, el 
// compilador añade extends Object
// public class Persona extends Object {
public class Persona {

	private String nombre;
	private int edad;
	private long telefono;
	
	// constructores
	// Siempre debemos mantener el constructor por defecto si se genera otro constructor
	public Persona() {
	}
	
	public Persona(String nombre, int edad, long telefono) {
		super();   // Llama al constructor de Object
		this.nombre = nombre;
		this.edad = edad;
		this.telefono = telefono;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}
	
	public long getTelefono() {
		return telefono;
	}
	
	public void setTelefono(long telefono) {
		this.telefono = telefono;
	}
	
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + edad;
		result = prime * result + ((nombre == null) ? 0 : nombre.hashCode());
		result = prime * result + (int) (telefono ^ (telefono >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		// Comparar si las direcciones de memoria son la misma
		if (this == obj)
			return true;
		// Compara si existe el otro objeto
		if (obj == null)
			return false;
		// Compara si son instancias de la misma clase
		if (getClass() != obj.getClass())
			return false;
		
		// Cambio la visibilidad del objeto a Persona (casting)
		Persona other = (Persona) obj;
		if (edad != other.edad)
			return false;
		if (nombre == null) {
			if (other.nombre != null)
				return false;
		} else if (!nombre.equals(other.nombre))
			return false;
		if (telefono != other.telefono)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "nombre=" + nombre + " edad=" + edad + " telefono=" + telefono + " ";
	}
	
}
