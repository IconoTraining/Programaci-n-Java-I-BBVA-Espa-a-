package es.bbva.models;

// Un tipo enumerado puede contener propiedades, constructores y metodos
public enum PuntoCardinal {
	
	NORTE('N', "North"),
	SUR('S', "South"),
	ESTE('E', "East"),
	OESTE('O', "West");
	
	// propiedad
	private char letra;
	private String ingles;
	
	// El constructor DEBE SER PRIVADO
	private PuntoCardinal(char letra, String ingles) {
		this.letra = letra;
		this.ingles = ingles;
	}
	
	// metodos
	public char getLetra() {
		return letra;
	}
	
	public String getIngles() {
		return ingles;
	}

}
