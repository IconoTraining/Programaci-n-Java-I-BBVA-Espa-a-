package es.bbva.main;

import es.bbva.models.EstadoCivil;
import es.bbva.models.Persona;
import es.bbva.models.PuntoCardinal;

public class AppMain {

	public static void main(String[] args) {
		
		Persona persona1 = new Persona("Pedro", 37, EstadoCivil.SOLTERO);
		Persona persona2 = new Persona("Maria", 52, EstadoCivil.CASADO);
		
		System.out.println(persona1);
		System.out.println(persona2);
		System.out.println("--------------");
		
		// Ver todos los estados disponibles
		// Los tipos enumerados heredan de la clase Enum
		for (EstadoCivil estado : EstadoCivil.values()) {
			System.out.println(estado);
		}
		System.out.println("--------------");
		
		System.out.println(EstadoCivil.valueOf("CASADO"));
		System.out.println(EstadoCivil.CASADO.ordinal());
		System.out.println("--------------");
		
		for (EstadoCivil estado : EstadoCivil.values()) {
			System.out.println(estado + ", ordinal: " + estado.ordinal());
		}
		System.out.println("--------------");
		
		
		// Crear un punto cardinal
		PuntoCardinal norte = PuntoCardinal.NORTE;
		System.out.println(norte);
		System.out.println(norte.getLetra());
		System.out.println(norte.getIngles());

	}

}
