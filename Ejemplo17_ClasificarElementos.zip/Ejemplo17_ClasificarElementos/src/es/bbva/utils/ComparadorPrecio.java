package es.bbva.utils;

import java.util.Comparator;

import es.bbva.models.Producto;

public class ComparadorPrecio implements Comparator<Producto>{

	@Override
	public int compare(Producto prod1, Producto prod2) {
		// 1 si prod1 es mayor
		// -1 si prod1 es menor
		// 0 si son iguales
		if (prod1.getPrecio() > prod2.getPrecio()) {
			return 1;
		} else if (prod1.getPrecio() < prod2.getPrecio()) {
			return -1;
		} else {
			return 0;
		}
	}

}
