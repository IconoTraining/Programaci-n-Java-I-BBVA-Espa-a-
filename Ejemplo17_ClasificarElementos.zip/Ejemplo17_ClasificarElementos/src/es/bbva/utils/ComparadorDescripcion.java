package es.bbva.utils;

import java.util.Comparator;

import es.bbva.models.Producto;

public class ComparadorDescripcion implements Comparator<Producto>{

	@Override
	public int compare(Producto prod1, Producto prod2) {
		
		return prod1.getDescripcion().compareTo(prod2.getDescripcion());
	}

}
