package es.bbva.main;

import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

import es.bbva.models.Producto;
import es.bbva.models.ProductoComparable;
import es.bbva.utils.ComparadorDescripcion;
import es.bbva.utils.ComparadorPrecio;

public class AppMain {

	public static void main(String[] args) {
		
		Set<ProductoComparable> productosPrecio = new TreeSet<>();
		productosPrecio.add(new ProductoComparable(1, "monitor", 129.50));
		productosPrecio.add(new ProductoComparable(2, "teclado", 29.50));
		productosPrecio.add(new ProductoComparable(3, "raton", 15));
		productosPrecio.add(new ProductoComparable(4, "impresora", 78.99));
		
		for (ProductoComparable producto : productosPrecio) {
			System.out.println(producto);
		}
		System.out.println("----------------");
		
		
		// Ordenar por descripcion
		//Set<Producto> productos = new TreeSet<>(new ComparadorDescripcion());
		
		// Ordenar por descripcion
		//Set<Producto> productos = new TreeSet<>(new ComparadorPrecio());
		
		// Ordenar por id
		Set<Producto> productos = new TreeSet<>(new Comparator<Producto>() {

			@Override
			public int compare(Producto prod1, Producto prod2) {
				if (prod1.getId() > prod2.getId()) {
					return 1;
				} else if (prod1.getId() < prod2.getId()) {
					return -1;
				} else {
					return 0;
				}
			}
		});
		productos.add(new Producto(1, "monitor", 129.50));
		productos.add(new Producto(2, "teclado", 29.50));
		productos.add(new Producto(3, "raton", 15));
		productos.add(new Producto(4, "impresora", 78.99));
		
		for (Producto producto : productos) {
			System.out.println(producto);
		}
		System.out.println("----------------");

	}

}
