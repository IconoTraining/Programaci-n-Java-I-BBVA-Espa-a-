package es.bbva;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AppMainGenericos {

	public static void main(String[] args) {
		
		// En java 5 y java 6
		// Set<String> nombres = new HashSet<String>();
		
		// A partir de Java 7
		// Set<String> nombres = new HashSet();
		Set<String> nombres = new HashSet<>();
		
		// nombres.add(1);   ERROR DE COMPILACION
		nombres.add("Pedro");
		nombres.add("Maria");
		nombres.add("Luis");
		nombres.add("Jose");
		nombres.add("Ana");
		
		for (String nombre : nombres) {
			System.out.println(nombre.toUpperCase());
			System.out.println(nombre.toLowerCase());
			System.out.println(nombre.length());
		}
		
		// No puedo utilizar el tipo primitivo como generico
		// List<int> numeros = new ArrayList<>();
		List<Integer> numeros = new ArrayList<>();
		numeros.add(8);
		numeros.add(new Integer(10));
		numeros.add(5);
		
		for (Integer num : numeros) {
			System.out.println(num * 2);
			System.out.println("Es par? " + (num % 2 == 0));
		}
		
		
		Map<String, Double> alumnos = new HashMap<String, Double>();
		alumnos.put("Jose", 7.3);
		alumnos.put("Marta", 5.2);
		alumnos.put("Pedro", 9.6);
		alumnos.put("Laura", 3.5);
		alumnos.put("Miguel", 8.4);
		alumnos.put("Irene", 4.2);
		
		System.out.println("Mis alumnos: " + alumnos.keySet());
		
		System.out.println("Alumnos-notas: ");
		for(Object dato: alumnos.entrySet()) {
			System.out.println(dato);
		}
		
		Collection<Double> notas =  alumnos.values();
		double suma = 0;
		for (Double nota : notas) {
			suma += nota;
		}
		System.out.println("Media del grupo: " + (suma / alumnos.size()));
		
		// Redondear a 2 decimales:  multiplico * 100, lo paso a entero y divido entre 100
		double media = suma / alumnos.size();
		int valor = (int)(media * 100);  // conversion
		System.out.println(valor);
		media = (double)valor / 100;   // conversion
		System.out.println("Media del grupo: " + media );
	}

}








