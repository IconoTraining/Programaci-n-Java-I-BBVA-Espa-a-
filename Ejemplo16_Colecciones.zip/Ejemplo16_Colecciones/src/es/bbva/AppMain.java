package es.bbva;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AppMain {

	public static void main(String[] args) {
		// Set -> No permite elementos duplicados, No se garantiza el orden de entrada
		// List -> Si se permite duplicados, Si garantiza el orden de entrada
		
		Set conjunto = new HashSet();
		conjunto.add(1);
		conjunto.add("Hola");
		conjunto.add(67.89);
		conjunto.add(true);
		conjunto.add("Adios");
		conjunto.add("Hola");   // Los repetidos no los añade, tampoco genera error
		System.out.println(conjunto);
		
		for (Object object : conjunto) {
			System.out.println(object);
		}
		
		
		List lista = new ArrayList();
		lista.add(1);
		lista.add("Hola");
		lista.add(67.89);
		lista.add(true);
		lista.add("Adios");
		lista.add("Hola");
		System.out.println(lista);
		
		for (Object object : lista) {
			System.out.println(object);
		}
		
		Iterator it = lista.iterator();
		while(it.hasNext()) {
			Object objeto = it.next();
			System.out.println(objeto);
		}
		
		
		// Map -> No heredan de Collection. Sus elementos son key-value
		// Las claves (key) no se pueden repetir
		// Los value si se pueden repetir
		// Tampoco se garantiza el orden de entrada
		
		Map mapa = new HashMap();
		mapa.put(1, "Hola");
		mapa.put("Adios", true);
		mapa.put(false, 2);
		mapa.put("Adios", false);   // Si repetimos la clave se sobreescribe ese valor
		
		System.out.println(mapa);
		
		System.out.println("Elementos: " + mapa.entrySet());
		Set entradas = mapa.entrySet();
		for (Object object : entradas) {
			System.out.println(object);
		}
		
		System.out.println("Keys: " + mapa.keySet());
		Set claves = mapa.keySet();
		for (Object object : claves) {
			System.out.println(object);
		}
		
		System.out.println("Valores: " + mapa.values());
		Collection valores = mapa.values();
		for(Object object : valores) {
			System.out.println(object);
		}
		
	}

}














