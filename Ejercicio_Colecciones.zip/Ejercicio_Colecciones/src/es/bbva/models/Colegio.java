package es.bbva.models;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Colegio {

	private String nombre;
	private List<String> profesores;
	private Set<Alumno> alumnos;
	private Map<String, String[]> asignaturas;  
	
	public Colegio() {
		profesores = new ArrayList<>();
		alumnos = new HashSet<>();
		asignaturas = new HashMap<>();
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public List<String> getProfesores() {
		return profesores;
	}

	public void setProfesores(List<String> profesores) {
		this.profesores = profesores;
	}

	public Set<Alumno> getAlumnos() {
		return alumnos;
	}

	public void setAlumnos(Set<Alumno> alumnos) {
		this.alumnos = alumnos;
	}

	public Map<String, String[]> getAsignaturas() {
		return asignaturas;
	}

	public void setAsignaturas(Map<String, String[]> asignaturas) {
		this.asignaturas = asignaturas;
	}
	
	

}
