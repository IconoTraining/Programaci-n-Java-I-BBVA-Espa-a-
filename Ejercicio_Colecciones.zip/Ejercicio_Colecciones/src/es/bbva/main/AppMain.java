package es.bbva.main;


import java.util.Arrays;
import java.util.Map.Entry;

import es.bbva.models.Alumno;
import es.bbva.models.Colegio;

public class AppMain {

	public static void main(String[] args) {
		
		Colegio colegio = new Colegio();
		
		colegio.setNombre("San Roman");
		
		// Añadimos profesores
		colegio.getProfesores().add("Miguel Fernandez");
		colegio.getProfesores().add("Maria Lopez");
		colegio.getProfesores().add("Luis Sanchez");
		colegio.getProfesores().add("Rosa Diaz");
		
		// Añadimos alumnos
		colegio.getAlumnos().add(new Alumno("Pedro", 12, 7.5));
		colegio.getAlumnos().add(new Alumno("Alicia", 13, 5.9));
		colegio.getAlumnos().add(new Alumno("Patricia", 12, 6.1));
		colegio.getAlumnos().add(new Alumno("Jose",13 , 8.3));
		colegio.getAlumnos().add(new Alumno("Miguel", 15, 9.5));
		colegio.getAlumnos().add(new Alumno("Alejandro", 14, 7.1));
		
		// Añadimos asignaturas
		colegio.getAsignaturas().put("Miguel Fernandez", new String[]{"lengua", "matematicas"});
		colegio.getAsignaturas().put("Maria Lopez", new String[]{"sociales"});
		colegio.getAsignaturas().put("Luis Sanchez", new String[] {"arte","musica"});
		colegio.getAsignaturas().put("Rosa Diaz", new String[] {"ingles", "fisica"});
		
		System.out.println("------------- INFO del colegio ---------------");
		System.out.println("Nombre: " + colegio.getNombre());
		System.out.println("Claustro: " + colegio.getProfesores());
		System.out.println("Alumnos");
		for (Alumno alum : colegio.getAlumnos()) {
			System.out.println(alum);
		}
		System.out.println("Tutorias");
		for(Entry<String, String[]> item : colegio.getAsignaturas().entrySet()) {
			System.out.println(item.getKey() + 
					", Asignaturas: " + Arrays.toString(item.getValue()));
		}

	}

}
