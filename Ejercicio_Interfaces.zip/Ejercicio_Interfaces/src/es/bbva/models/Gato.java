package es.bbva.models;

public class Gato extends Animal{
	
	private boolean estaVacunado;
	
	public Gato() {
		// TODO Auto-generated constructor stub
	}

	public Gato(boolean estaVacunado) {
		super();
		this.estaVacunado = estaVacunado;
	}

	public boolean isEstaVacunado() {
		return estaVacunado;
	}

	public void setEstaVacunado(boolean estaVacunado) {
		this.estaVacunado = estaVacunado;
	}

	@Override
	public String toString() {
		return "Gato [estaVacunado=" + estaVacunado + "]";
	}
	
}
