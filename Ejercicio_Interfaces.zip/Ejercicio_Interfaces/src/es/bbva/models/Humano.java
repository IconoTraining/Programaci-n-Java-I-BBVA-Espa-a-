package es.bbva.models;

public class Humano implements AccionesHumano, AccionesGeneral{
	
	private char sexo;
	
	public Humano() {
		// TODO Auto-generated constructor stub
	}
		
	public Humano(char sexo) {
		super();
		this.sexo = sexo;
	}

	public char getSexo() {
		return sexo;
	}

	public void setSexo(char sexo) {
		this.sexo = sexo;
	}

	@Override
	public void hablar() {
		System.out.println("Los humanos hablan");
	}

	@Override
	public void desplazarse() {
		System.out.println("Los humanos se desplazan");
	}

	@Override
	public void jugar() {
		System.out.println("Los humanos juegan");
	}

	@Override
	public void alimentarse() {
		System.out.println("Los humanos se alimentan");
	}

	@Override
	public void dormir() {
		System.out.println("Los humanos duermen");
	}

	@Override
	public void bailar() {
		System.out.println("Los humanos bailan");
	}

	@Override
	public void tocarInstrumentos() {
		System.out.println("Los humanos tocan instrumentos");
	}

	@Override
	public void estudiar() {
		System.out.println("Los humanos estudian");
	}

	@Override
	public void trabajar() {
		System.out.println("Los humanos trabajan");
	}

	@Override
	public String toString() {
		return "sexo=" + sexo + " ";
	}
	
}
