package es.bbva.models;

public class Animal implements AccionesGeneral {

	@Override
	public void hablar() {
		System.out.println("Los animales se comunican");
	}

	@Override
	public void desplazarse() {
		System.out.println("Los animales se desplazan");
	}

	@Override
	public void jugar() {
		System.out.println("Los animales juegan");
	}

	@Override
	public void alimentarse() {
		System.out.println("Los animales se alimentan");
	}

	@Override
	public void dormir() {
		System.out.println("Los animales duermen");
	}

}
