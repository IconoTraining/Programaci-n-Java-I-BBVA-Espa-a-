package es.bbva.models;

public class Perro extends Animal{
	
	private String raza;
	
	public Perro() {
		// TODO Auto-generated constructor stub
	}

	public Perro(String raza) {
		super();
		this.raza = raza;
	}

	public String getRaza() {
		return raza;
	}

	public void setRaza(String raza) {
		this.raza = raza;
	}

	@Override
	public String toString() {
		return "Perro [raza=" + raza + "]";
	}
	
}
