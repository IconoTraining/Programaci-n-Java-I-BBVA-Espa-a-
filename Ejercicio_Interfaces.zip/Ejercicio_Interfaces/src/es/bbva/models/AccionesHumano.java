package es.bbva.models;

public interface AccionesHumano {
	
	void bailar();
	void tocarInstrumentos();
	void estudiar();
	void trabajar();

}
