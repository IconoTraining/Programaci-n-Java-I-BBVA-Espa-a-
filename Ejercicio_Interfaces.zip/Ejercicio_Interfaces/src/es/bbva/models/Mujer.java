package es.bbva.models;

public class Mujer extends Humano{
	
	private float altura;
	private String colorPelo;
	
	public Mujer() {
		super('M');
	}

	public Mujer(float altura, String colorPelo) {
		super('M');
		this.altura = altura;
		this.colorPelo = colorPelo;
	}

	public float getAltura() {
		return altura;
	}

	public void setAltura(float altura) {
		this.altura = altura;
	}

	public String getColorPelo() {
		return colorPelo;
	}

	public void setColorPelo(String colorPelo) {
		this.colorPelo = colorPelo;
	}

	@Override
	public String toString() {
		return super.toString() + "altura=" + altura + ", colorPelo=" + colorPelo + " ";
	}

}
