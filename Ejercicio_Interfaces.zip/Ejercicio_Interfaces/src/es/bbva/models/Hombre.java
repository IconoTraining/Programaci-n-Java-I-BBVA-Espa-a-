package es.bbva.models;

public class Hombre extends Humano{
	
	private String nombre;
	private int edad;
	
	public Hombre() {
		super('H');
	}

	public Hombre(String nombre, int edad) {
		super('H');
		this.nombre = nombre;
		this.edad = edad;
	}

	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	@Override
	public String toString() {
		return super.toString() + "nombre=" + nombre + ", edad=" + edad + " ";
	}
	
}
