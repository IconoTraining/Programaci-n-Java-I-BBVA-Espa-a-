package es.bbva.models;

public interface AccionesGeneral {
	
	void hablar();
	void desplazarse();
	void jugar();
	void alimentarse();
	void dormir();

}
