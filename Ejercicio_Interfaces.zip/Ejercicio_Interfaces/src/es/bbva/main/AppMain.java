package es.bbva.main;

import es.bbva.models.Gato;
import es.bbva.models.Hombre;
import es.bbva.models.Mujer;
import es.bbva.models.Perro;

public class AppMain {

	public static void main(String[] args) {
		
		Hombre hombre = new Hombre();
		hombre.setNombre("Juan");
		hombre.setEdad(38);
		System.out.println(hombre);
		hombre.hablar();
		hombre.estudiar();
		hombre.tocarInstrumentos();
		
		Mujer mujer = new Mujer();
		mujer.setAltura(1.70F);
		mujer.setColorPelo("Rubio");
		System.out.println(mujer);
		mujer.bailar();
		mujer.desplazarse();
		
		Perro perro = new Perro("Caniche");
		System.out.println(perro);
		perro.alimentarse();
		perro.dormir();
		
		Gato gato = new Gato(false);
		System.out.println(gato);
		gato.jugar();
		gato.hablar();
		gato.desplazarse();
	}

}
