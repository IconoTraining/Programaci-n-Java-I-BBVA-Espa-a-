package es.bbva.main;

import es.bbva.business.Operaciones;

public class AppMain {

	public static void main(String[] args) {
		
		// Crear un objeto o instancia de la clase Operaciones
		Operaciones operaciones = new Operaciones();
		
		// Invocar a los métodos
		System.out.println("3 + 5 = " + operaciones.sumar(3, 5));
		System.out.println("10 - 7 = " + operaciones.restar(10, 7));
		System.out.println("2 * 3 = " + operaciones.multiplicar(2, 3));
		System.out.println("9 / 3 = " + operaciones.dividir(9, 3));
		System.out.println("10 / 3 = " + operaciones.resto(10, 3));

	}

}
