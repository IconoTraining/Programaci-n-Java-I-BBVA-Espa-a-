package es.bbva.business;

public class Operaciones {
	
	public double sumar(double num1, double num2) {
		double resultado = num1 + num2;
		return resultado;
	}
	
	public double restar(double num1, double num2) {
		return num1 - num2;
	}
	
	public double multiplicar(double num1, double num2) {
		return num1 * num2;
	}
	
	public double dividir(double num1, double num2) {
		return num1 / num2;
	}
	
	public double resto(double num1, double num2) {
		return num1 % num2;
	}

}
