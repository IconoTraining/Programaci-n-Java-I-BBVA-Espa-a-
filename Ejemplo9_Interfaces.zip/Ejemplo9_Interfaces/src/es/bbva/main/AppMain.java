package es.bbva.main;

import es.bbva.models.Pajaro;
import es.bbva.models.Perro;

public class AppMain {

	public static void main(String[] args) {
		
		Perro perro = new Perro("Pastor aleman", 1, 'M', true, 295, "PE-001");
		System.out.println(perro);
		
		Pajaro pajaro = new Pajaro("Jilguero", 2, 65, "JI-002", true);
		System.out.println(pajaro);
		pajaro.despegar();
		pajaro.aterrizar();

	}

}
