package es.bbva.models;

public class Pajaro extends Animal implements ProductoVenta, ObjetoVolador{
	
	private double precio;
	private String codigo;
	private boolean canta;
	
	public Pajaro() {
	}

	public Pajaro(String nombre, int edad, double precio, String codigo, boolean canta) {
		super(nombre, edad);
		this.precio = precio;
		this.codigo = codigo;
		this.canta = canta;
	}

	@Override
	public void despegar() {
		System.out.println("El pajaro empieza a volar");
	}

	@Override
	public void aterrizar() {
		System.out.println("El pajaro se posa en el arbol");
	}

	@Override
	public double getPrecio() {
		return precio;
	}

	@Override
	public String getCodigo() {
		return codigo;
	}

	@Override
	public void setPrecio(double precio) {
		this.precio = precio;
	}

	@Override
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public boolean isCanta() {
		return canta;
	}

	public void setCanta(boolean canta) {
		this.canta = canta;
	}

	@Override
	public String toString() {
		return super.toString() + "precio=" + precio + ", codigo=" + codigo + ", canta=" + canta;
	}
	
}
