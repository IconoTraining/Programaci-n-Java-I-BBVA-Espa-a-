package es.bbva.models;

public interface ProductoVenta {
	
	// Todas las propiedades en una interface se consideran static y final (constante)
	
	// Todos los metodos se consideran public y abstract
	public abstract double getPrecio();
	String getCodigo();
	abstract void setPrecio(double precio);
	public void setCodigo(String codigo);

}
