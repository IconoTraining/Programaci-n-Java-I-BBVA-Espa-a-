package es.bbva.models;

public class Perro extends Animal implements ProductoVenta {

	private char sexo;
	private boolean vacunado;

	// Crear las propiedades para poder completar los metodos
	private double precio;
	private String codigo;

	public Perro() {
	}

	public Perro(String nombre, int edad, char sexo, boolean vacunado, 
			double precio, String codigo) {
		super(nombre, edad);
		this.sexo = sexo;
		this.vacunado = vacunado;
		this.precio = precio;
		this.codigo = codigo;
	}

	@Override
	public double getPrecio() {
		return precio;
	}

	@Override
	public void setPrecio(double precio) {
		this.precio = precio;
	}

	@Override
	public String getCodigo() {
		return codigo;
	}

	@Override
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public char getSexo() {
		return sexo;
	}

	public void setSexo(char sexo) {
		this.sexo = sexo;
	}

	public boolean isVacunado() {
		return vacunado;
	}

	public void setVacunado(boolean vacunado) {
		this.vacunado = vacunado;
	}

	@Override
	public String toString() {
		return super.toString() + "sexo=" + sexo + ", vacunado=" + vacunado + ", precio=" + precio + ", codigo="
				+ codigo;
	}

}
