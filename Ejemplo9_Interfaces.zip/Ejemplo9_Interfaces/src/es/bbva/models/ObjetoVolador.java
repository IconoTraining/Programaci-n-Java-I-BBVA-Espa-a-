package es.bbva.models;

public interface ObjetoVolador {
	
	void despegar();
	void aterrizar();

}
