package es.bbva;

public class AppMain {

	public static void main(String[] args) {
		
		// Tipos enteros
		byte numByte = 6;
		short numShort = 786;
		int numInteger = 654433;   // defecto
		long numLong = 65323468987654332L;   // L o l
		
		// Tipos reales
		float numFloat = 3.1416F;  // F o f
		double numDouble = 56643.654467;   // defecto
		
		// Tipo logico
		boolean tipoBoolean = true;  
		
		// Tipo textual - caracteres, con comillas simples
		char letra = 'a';
		char tabulador = '\t';
		
		// Tipo String es una clase
		String cadena = "Hola, que tal?";
		

	}

}
