package es.bbva.business;

import es.bbva.utils.DivisorException;

public class Calculadora {
	
	public double dividir(int dividendo, int divisor) throws DivisorException {
		
		if (divisor == 0) {
			// lanzar una excepcion
			throw new DivisorException("El divisor no puede ser 0");
		}
		
		return dividendo / divisor;
	}

}
