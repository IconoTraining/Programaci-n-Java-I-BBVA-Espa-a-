package es.bbva.utils;

// Creo una excepcion personalizada

//Los RuntimeExcepcion no me obligan a manejar la excepcion
//public class DivisorException extends RuntimeException{
	
	
public class DivisorException extends RuntimeException{

	public DivisorException(String mensaje) {
		super(mensaje);
	}
}
