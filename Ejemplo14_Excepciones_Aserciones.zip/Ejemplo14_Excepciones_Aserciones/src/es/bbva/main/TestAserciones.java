package es.bbva.main;

public class TestAserciones {

	public static void main(String[] args) {
		
		// Espero que el numero sea positivo, mayor de 0.
		int numero = -7;
		
		if (numero > 0) {
			System.out.println("El numero es positivo");
		} else {
			
			// Afirmamos que el numero es cero.
			// Si no lo es, lanza un AssertionError
			assert (numero == 0): "El numero no es cero";
			System.out.println("El numero es cero");
		}

	}

}
