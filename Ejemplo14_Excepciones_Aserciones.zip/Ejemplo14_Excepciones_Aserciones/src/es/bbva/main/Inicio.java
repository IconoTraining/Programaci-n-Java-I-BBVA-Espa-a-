package es.bbva.main;

import java.util.Arrays;

import es.bbva.business.Calculadora;
import es.bbva.utils.DivisorException;

public class Inicio {

	public static void main(String[] args) {
		
		System.out.println(Arrays.toString(args));
		
		int suma = 0;
		for(String dato : args) {
			
			int numero = 0;
			
			try {
				numero = Integer.parseInt(dato);
			} catch (NumberFormatException e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			} catch (Exception e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			} finally {
				// Se ejecuta siempre, haya excepcion o no
				suma += numero;
			}
			
		}
		
		System.out.println("Suma: " + suma);
		
		
		Calculadora calcu = new Calculadora();
		try {
			System.out.println("7 / 0 = " + calcu.dividir(7, 0));
		} catch (DivisorException e) {
			e.printStackTrace();
		}
		
		// Si es RuntimeException no necesitamos capturar la excepcion
		System.out.println("7 / 0 = " + calcu.dividir(7, 0));
		
		
		

	} // fin main

} // Fin clase
