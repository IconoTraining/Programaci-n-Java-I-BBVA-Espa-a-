package es.bbva;

public class Main {

	// Es el unico metodo que reconoce la máquina virtual
	public static void main(String[] args) {
		
		// syso + ctrl + space
		System.out.println("Bienvenidos al curso de Java");	
	}

}
