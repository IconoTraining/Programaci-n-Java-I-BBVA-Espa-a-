package es.bbva.business;

public class Calculadora {
	
	public double sumar(double n1, double n2) {
		return n1 + n2;
	}
	
	public double sumar(double n1, double n2, double n3) {
		return n1 + n2 + n3;
	}
	
	// ctrl + shift + c   -> comentas y descomentas
//	public double sumar(double[] numeros) {
//		
//		double suma = 0;
//		for(double num : numeros) {
//			suma += num;
//		}
//		return suma;
//	}
	
	// A partir de Java 7 se permite numero variable argumentos
	// tipo... argumento
	public double sumar(double... numeros) {
		// Internamente con los argumentos recibidos se genera un array

		double suma = 0;
		for(double num : numeros) {
			suma += num;
		}
		return suma;
	}

}
