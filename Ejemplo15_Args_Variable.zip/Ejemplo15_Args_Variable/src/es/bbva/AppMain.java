package es.bbva;

import es.bbva.business.Calculadora;

public class AppMain {

	public static void main(String[] args) {
		
		Calculadora calculadora = new Calculadora();
		
		System.out.println(calculadora.sumar(5, 7));
		System.out.println(calculadora.sumar(1, 2, 3));
		System.out.println(calculadora.sumar(new double[] {5, 6, 7, 8} ));
		System.out.println(calculadora.sumar(5, 6, 7, 8));
		System.out.println(calculadora.sumar());
		System.out.println(calculadora.sumar(8));

	}

}
