package es.bbva.models;

public class Producto {
	
	// Propiedades o recursos de instancia
	// Cada instancia tiene una copia de estas propiedades
	private final int ID;   // constante
	private String descripcion;
	private double precio;
	
	// Recurso de clase. Clase solo hay una
	// Solo existe una copia y reside en la clase
	private static int contador;
	
	static {
		contador = 0;
	}
	
	// Constructores
	public Producto() {
		ID = ++contador;
	}

	public Producto(String descripcion, double precio) {
		super();
		this.descripcion = descripcion;
		this.precio = precio;
		ID = ++contador;
	}
	
	
	// Metodo de clase
	public static int getContador() {
		// id++; error
		// Desde un método estático solo se accede a recursos estáticos
		// porque es lo que te aseguras que esta en memoria
 		return contador;
	}
	
	// Metodos de instancia
	public int getID() {
		return ID;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	@Override
	public String toString() {
		return "Producto [id=" + ID + ", descripcion=" + descripcion + ", precio=" + precio + "]";
	}
	
}
