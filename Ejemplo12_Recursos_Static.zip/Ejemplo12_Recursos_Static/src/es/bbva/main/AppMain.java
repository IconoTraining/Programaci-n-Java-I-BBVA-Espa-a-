package es.bbva.main;

import es.bbva.models.Producto;

public class AppMain {

	// Los metodo estaticos no es necesario crear una instancia para invocarlos
	// Como la JVM llama a la clase principal:
	// AppMain.main(.....)
	public static void main(String[] args) {
		
		Producto p1 = new Producto("Pantalla", 149.50);
		Producto p2 = new Producto("Teclado", 29.95);
		Producto p3 = new Producto("Impresora", 89.20);
		
		System.out.println("Cuantos productos tengo? " + Producto.getContador());
		
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(p3);

	}

}
