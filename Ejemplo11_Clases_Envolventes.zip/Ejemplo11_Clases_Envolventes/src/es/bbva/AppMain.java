package es.bbva;

public class AppMain {

	public static void main(String[] args) {
		
		int numero = 6558;
		Integer objInteger = 8;
		System.out.println(objInteger.toHexString(numero));
		System.out.println(objInteger.toOctalString(numero));
		System.out.println(objInteger.toBinaryString(numero));
		
		// Boxing.  primitivo -> objeto
		int n = 10;
		Integer obj = new Integer(n);

		
		// Unboxing.   objeto -> primitivo
		n = obj.intValue();
		
		
		// Autoboxing.   Ambas tareas de forma automatica
		n = obj;    // el tipo primitivo acepta un objeto
		obj = n;    // el objeto acepta un tipo primitivo
		
		
		// Ejemplo de metodos de las clases envolventes
		System.out.println("Maximo entre 8 y 5: " + Integer.max(8, 5));
		System.out.println("H es una letra? " + Character.isLetter('h'));
		System.out.println("H es un digito? " + Character.isDigit('h'));
		
		String texto = "1234";
		int num = Integer.parseInt(texto);
		num++;
		System.out.println(num);
		
	}

}
